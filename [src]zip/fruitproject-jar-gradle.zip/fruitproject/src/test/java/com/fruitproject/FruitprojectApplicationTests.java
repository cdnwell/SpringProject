package com.fruitproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FruitprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}

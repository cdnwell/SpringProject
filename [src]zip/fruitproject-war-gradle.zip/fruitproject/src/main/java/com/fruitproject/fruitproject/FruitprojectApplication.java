package com.fruitproject.fruitproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FruitprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(FruitprojectApplication.class, args);
	}

}
